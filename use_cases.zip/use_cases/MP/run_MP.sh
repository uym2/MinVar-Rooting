#! /bin/bash

FastRoot.py -m MP -i input.trees -o output.trees
