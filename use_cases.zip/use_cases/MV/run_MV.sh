#! /bin/bash

FastRoot.py -m MV -i input.trees -o output.trees 
