#! /bin/bash

FastRoot.py -m OG -i input.trees -g "`cat outgroups.txt`" -o output.trees
