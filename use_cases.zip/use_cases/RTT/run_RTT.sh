#! /bin/bash

FastRoot.py -m RTT -i input.trees -t sampling_times.txt -o output.trees
